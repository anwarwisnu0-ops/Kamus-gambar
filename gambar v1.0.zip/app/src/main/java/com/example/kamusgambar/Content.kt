package com.example.kamusgambar

class Lesson(
    val id: String, val title: String, val level: String, val diagram: String,
    val body: String, val steps: List<String>, val check: List<String>
)
class Term(val term: String, val def: String)
class Style(val name: String, val axes: FloatArray, val ciri: String, val resep: List<String>)

val LESSONS = listOf(
    Lesson("alat", "0. Alat & Posisi Tangan", "Dasar awal", "alat",
        "Kamu tidak butuh alat mahal. Pensil bertanda H keras dan menghasilkan garis tipis yang terang, pensil B lunak dan menghasilkan garis tebal yang gelap, HB ada di tengah. Mulailah dengan HB dan 2B, kertas sketsa biasa, penghapus karet, dan kalau ada penghapus kneaded (bisa dibentuk, mengangkat grafit tanpa merusak kertas). Cara memegang pensil menentukan jenis garis: pegang agak jauh dari ujung untuk garis longgar dan luwes, dekat ujung untuk detail kecil.",
        listOf("Pegang pensil seperti menulis, lalu geser pegangan 3-4 cm dari ujung. Tarik beberapa garis panjang.",
            "Gerakkan lengan dari bahu atau siku untuk garis panjang, dari pergelangan untuk garis pendek.",
            "Buat kotak kecil dengan HB dan 2B: tekan dari ringan sampai kuat dan lihat bedanya."),
        listOf("Garis panjang terasa tidak kaku", "Tanganku tidak pegal karena menggenggam terlalu erat", "Aku bisa membuat gelap dan terang lewat tekanan")),
    Lesson("garis", "1. Kontrol Garis", "Dasar awal", "garis",
        "Garis yang yakin ditarik dalam satu gerakan, bukan digores berulang-ulang. Latihan kontrol garis melatih mata dan tangan bekerja sama. Triknya disebut ghosting: gerakkan pensil di atas kertas tanpa menyentuh dua atau tiga kali, baru tarik garis sungguhan. Arsiran (hatching) membuat gelap lewat garis sejajar, dan arsiran silang (cross-hatching) menumpuk arah garis untuk gelap yang lebih pekat.",
        listOf("Isi setengah halaman dengan garis lurus dari titik ke titik. Lakukan ghosting dulu.",
            "Gambar garis lengkung berbentuk S yang halus, lalu gelombang yang rata.",
            "Buat kotak 3x3 cm, isi dengan arsiran sejajar berjarak sama.",
            "Tumpuk arsiran kedua yang menyilang untuk arsiran silang."),
        listOf("Garis ditarik sekali jalan, tidak dikerik", "Jarak arsiranku terlihat rata", "Garisku mulai tepat ke titik yang kutuju")),
    Lesson("bentuk", "2. Bentuk Dasar", "Dasar awal", "bentuk",
        "Hampir semua benda bisa dipecah menjadi tiga bentuk dasar: lingkaran, kotak, dan segitiga. Mulai dari bentuk besar yang sederhana, baru tambahkan detail. Kebiasaan ini mencegah gambar yang detail di satu tempat tetapi bentuk besarnya meleset.",
        listOf("Gambar 10 lingkaran dengan satu putaran tangan, tanpa menghapus.",
            "Gambar kotak dengan sudut tegak lurus, lalu segitiga sama sisi.",
            "Pilih tiga benda di meja. Gambar bentuk dasarnya saja, 2 menit per benda."),
        listOf("Lingkaranku mulai menutup dengan rapi", "Aku bisa melihat bentuk dasar pada benda sehari-hari", "Aku menggambar bentuk besar dulu sebelum detail")),
    Lesson("3d", "3. Bentuk 3D (Form)", "Dasar awal", "3d",
        "Bentuk (shape) itu datar, sedangkan form punya volume. Empat form dasar adalah bola, kubus, silinder, dan kerucut. Garis lintang (contour lines) yang melengkung di permukaan membantu mata merasakan volume. Lingkaran yang dilihat dari samping tampak sebagai elips, dan makin sejajar dengan level matamu, makin pipih elipsnya.",
        listOf("Gambar kubus dari tiga sudut berbeda. Pastikan sisi yang sejajar terlihat sejajar.",
            "Gambar silinder: dua elips (atas dan bawah) dihubungkan dua garis sisi.",
            "Gambar bola, lalu tambahkan dua garis lintang melengkung.",
            "Gabungkan: gambar tumpukan kubus, silinder, dan bola."),
        listOf("Sisi kubusku terlihat sejajar", "Elipsku halus, bukan lonjong bersudut", "Garis lintang membuat bola terlihat bulat")),
    Lesson("proporsi", "4. Proporsi & Mengukur", "Dasar awal", "proporsi",
        "Proporsi adalah perbandingan ukuran antar bagian. Cara mengukurnya: luruskan tangan ke depan sambil memegang pensil, lalu pakai panjang pensil untuk membandingkan tinggi dan lebar. Gambar kotak batas (bounding box) objek dulu, baru isi. Perhatikan juga ruang kosong di sekitar objek (ruang negatif). Patokan umum untuk kepala realis: mata di sekitar tengah tinggi kepala, hidung di tengah antara mata dan dagu, lebar wajah sekitar lima lebar mata. Gaya kartun dan anime sengaja menyimpang dari ukuran ini.",
        listOf("Ukur sebuah benda dengan pensil di lengan lurus. Catat perbandingan tinggi dan lebarnya.",
            "Gambar kotak batas dengan perbandingan itu, lalu isi bentuk di dalamnya.",
            "Gambar oval kepala, tarik garis tengah tegak dan datar, lalu letakkan mata di garis datar."),
        listOf("Kotak batasku mirip perbandingan aslinya", "Aku memeriksa ukuran sebelum menambah detail", "Aku tahu patokan letak mata pada kepala")),
    Lesson("gelap", "5. Gelap-Terang (Value)", "Dasar awal", "gelap",
        "Value adalah tingkat gelap-terang, dan ini lebih menentukan keterbacaan bentuk daripada garis. Dengan satu sumber cahaya pada sebuah bola kamu akan melihat: highlight (paling terang), midtone, core shadow (bayangan inti, belum tentu yang paling gelap), reflected light (pantulan tipis di sisi gelap), dan cast shadow (bayangan jatuh di permukaan). Menyipitkan mata membantu melihat kelompok gelap-terang besar. Pakai mode 3 tone dan 5 tone di Studio Referensi untuk melatihnya.",
        listOf("Buat skala 7 kotak dari paling terang sampai paling gelap.",
            "Gambar bola dengan satu sumber cahaya dan 5 tingkat gelap-terang.",
            "Pilih satu benda, ubah fotonya ke 3 tone di Studio, lalu gambar tiga kelompok itu."),
        listOf("Skala gelap-terangku bertahap rata", "Bolaku punya highlight dan bayangan jatuh", "Aku bisa mengelompokkan gelap-terang jadi 3 bagian"))
)

val TERMS = listOf(
    Term("Arsiran (hatching)", "Garis-garis sejajar untuk membuat area terlihat lebih gelap."),
    Term("Arsiran silang (cross-hatching)", "Dua atau lebih lapisan arsiran dengan arah menyilang untuk gelap yang lebih pekat."),
    Term("Bayangan inti (core shadow)", "Bagian gelap pada bentuk 3D yang berada di antara sisi terang dan pantulan cahaya."),
    Term("Bayangan jatuh (cast shadow)", "Bayangan yang dijatuhkan objek ke permukaan di dekatnya."),
    Term("Bentuk (shape)", "Bidang datar dua dimensi seperti lingkaran, kotak, dan segitiga."),
    Term("Form", "Bentuk tiga dimensi yang punya volume, seperti bola, kubus, dan silinder."),
    Term("Cahaya pantul (reflected light)", "Cahaya tipis yang memantul dari permukaan sekitar ke sisi gelap objek."),
    Term("Cahaya tepi (rim light)", "Garis cahaya tipis di tepi objek, biasanya dari sumber cahaya di belakang."),
    Term("Fokus utama (focal point)", "Bagian gambar yang paling menarik mata."),
    Term("Foreshortening", "Pemendekan tampilan objek yang mengarah ke penonton, sehingga terlihat lebih pendek dari aslinya."),
    Term("Garis bantu (construction line)", "Garis tipis awal untuk menyusun bentuk dan proporsi, nanti dihapus atau ditimpa."),
    Term("Garis cakrawala (horizon line)", "Garis setinggi level mata pengamat. Titik hilang berada di garis ini."),
    Term("Garis lintang (contour line)", "Garis melengkung di permukaan form yang menunjukkan arah volumenya."),
    Term("Gesture", "Sketsa cepat yang menangkap gerak dan arah utama pose, tanpa detail."),
    Term("Highlight", "Bagian paling terang pada objek, tempat cahaya langsung memantul."),
    Term("Kekontrasan (contrast)", "Perbedaan antara bagian gelap dan terang, atau antar warna."),
    Term("Komposisi", "Cara menata elemen dalam bidang gambar."),
    Term("Level mata (eye level)", "Ketinggian posisi mata pengamat, sama dengan garis cakrawala."),
    Term("Midtone", "Tingkat gelap-terang di tengah antara highlight dan bayangan."),
    Term("Penghapus kneaded", "Penghapus lunak yang bisa dibentuk, mengangkat grafit tanpa merusak kertas."),
    Term("Perspektif", "Cara menggambar ruang tiga dimensi di bidang datar, sehingga objek mengecil saat menjauh."),
    Term("Perspektif atmosfer", "Objek yang jauh tampak lebih pucat, kurang kontras, dan kurang detail."),
    Term("Proporsi", "Perbandingan ukuran antar bagian dalam satu objek atau gambar."),
    Term("Ruang negatif (negative space)", "Ruang kosong di sekitar dan antara objek. Menggambarnya membantu mengukur bentuk."),
    Term("Siluet", "Bentuk luar objek yang diisi satu tone, tanpa detail di dalam."),
    Term("Sketsa kecil (thumbnail)", "Sketsa komposisi berukuran sangat kecil untuk mencoba beberapa penataan dengan cepat."),
    Term("Sumber cahaya", "Asal cahaya yang menentukan arah gelap-terang dan bayangan."),
    Term("Tebal garis (line weight)", "Tebal-tipis garis. Garis tebal biasanya untuk tepi depan atau bayangan, garis tipis untuk detail."),
    Term("Tekstur", "Kesan permukaan seperti kasar, halus, atau berbulu."),
    Term("Tone (nada gelap-terang)", "Tingkat gelap-terang dari putih sampai hitam, tidak tergantung warna."),
    Term("Titik hilang (vanishing point)", "Titik di garis cakrawala tempat garis-garis sejajar tampak bertemu."),
    Term("Tumpang tindih (overlap)", "Objek di depan menutup sebagian objek di belakang, memberi kesan kedalaman."),
    Term("Value", "Tingkat gelap-terang. Istilah lain untuk tone."),
    Term("Ghosting", "Menggerakkan tangan di atas kertas tanpa menyentuh dua-tiga kali sebelum menarik garis sungguhan."),
    Term("Kotak batas (bounding box)", "Kotak yang membungkus objek, dipakai untuk memeriksa tinggi dan lebar sebelum mengisi detail.")
).sortedBy { it.term.lowercase() }

val STYLES = listOf(
    Style("Anime", floatArrayOf(5f, 4f, 2f, 4f, 2f),
        "Garis tepi tegas dan bersih, bentuk wajah disederhanakan (mata besar, hidung dan mulut minimal), warna rata dengan bayangan bertingkat sedikit.",
        listOf("Gambar garis kelopak atas yang tebal dan tegas.", "Buat iris besar berbentuk oval tegak, sisakan satu highlight.", "Tambah kelopak bawah dengan garis tipis.", "Beri alis sederhana dan warnai dengan tone rata.")),
    Style("Semi-realis", floatArrayOf(3f, 3f, 3f, 4f, 3f),
        "Proporsi mendekati nyata tetapi disederhanakan. Garis tepi lebih halus, bayangan lebih banyak tingkat, detail sedang.",
        listOf("Gambar bentuk mata seperti almond, dengan lipatan kelopak.", "Letakkan iris yang tertutup sedikit kelopak atas.", "Tambah bayangan lembut di bawah kelopak atas.", "Beri highlight kecil dan garis bulu mata yang menyatu.")),
    Style("Realis", floatArrayOf(1f, 1f, 5f, 5f, 5f),
        "Berdasarkan pengamatan. Bentuk dibangun dari gelap-terang yang halus, garis tepi hampir tidak terlihat, tekstur dan detail kaya.",
        listOf("Amati mata sebagai bola dengan kelopak yang membungkusnya.", "Bangun bentuk dengan gelap-terang halus, bukan garis.", "Tambahkan tekstur bulu mata dan bayangannya di bola mata.", "Letakkan highlight kecil yang tajam di akhir."))
)

val PRACTICE = listOf(
    "Dasar awal | 10 menit | Isi satu halaman dengan garis lurus panjang. Lakukan ghosting dulu.",
    "Dasar awal | 10 menit | Gambar 20 lingkaran dengan satu putaran, tanpa menghapus.",
    "Dasar awal | 10 menit | Buat 10 kotak arsiran dengan kerapatan berbeda.",
    "Dasar awal | 10 menit | Gambar kubus dari 3 sudut berbeda.",
    "Dasar awal | 10 menit | Gambar silinder dengan elips yang halus, lima kali.",
    "Dasar awal | 15 menit | Buat skala gelap-terang 7 kotak.",
    "Dasar awal | 15 menit | Gambar bola dengan satu sumber cahaya dan 5 tingkat.",
    "Dasar awal | 10 menit | Gambar tiga benda di mejamu sebagai bentuk dasar saja.",
    "Dasar awal | 10 menit | Gambar garis lengkung S sebanyak mungkin, setiap garis sekali jalan.",
    "Dasar awal | 15 menit | Ukur satu benda dengan pensil, gambar kotak batas, lalu isi.",
    "Dasar awal | 10 menit | Gambar cangkir dari bentuk dasar: silinder dan elips.",
    "Dasar awal | 10 menit | Gambar tumpukan kubus, silinder, dan bola.",
    "Dasar awal | 15 menit | Pilih foto di Studio, ubah ke 3 tone, gambar tiga kelompok itu.",
    "Dasar awal | 10 menit | Gambar telur dengan cast shadow di bawahnya.",
    "Dasar awal | 10 menit | Gambar 5 gesture tangan, masing-masing 1 menit.",
    "Dasar awal | 15 menit | Gambar kepala sebagai oval, lalu garis tengah dan garis mata.",
    "Dasar awal | 10 menit | Gambar siluet tanamanmu, isi dengan satu tone.",
    "Dasar awal | 15 menit | Gambar benda yang sama dua kali: sekali dengan garis, sekali dengan gelap-terang saja.",
    "Dasar awal | 10 menit | Pakai mode cermin di Studio, gambar ulang gambarmu dan cari kesalahan.",
    "Dasar awal | 10 menit | Isi satu halaman dengan arsiran silang yang makin rapat.",
    "Dasar awal | 15 menit | Gambar sepatumu dengan kotak batas lebih dulu.",
    "Dasar awal | 10 menit | Gambar bola, kubus, silinder dengan arah cahaya yang sama.",
    "Dasar awal | 10 menit | Gesture 10 benda acak dari Timer, masing-masing 30 detik.",
    "Dasar awal | 15 menit | Gambar ruang negatif di sekitar kursi, bukan kursinya."
)

val PROMPTS = listOf(
    "cangkir", "sepatu", "tanganmu sendiri", "kursi", "tanaman", "botol", "buku terbuka", "kunci",
    "kacamata", "headset", "ponsel", "jeruk atau apel", "lampu meja", "tas", "jam tangan",
    "kaleng", "gunting", "sisir", "topi", "kipas kecil"
)
