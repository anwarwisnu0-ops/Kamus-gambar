package com.example.kamusgambar

import android.content.Context
import android.graphics.*
import android.view.View

// Diagram pelajaran digambar lewat kode, di atas "kertas".
class DiagramView(ctx: Context, private val type: String) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ink = Color.parseColor("#2B2622")

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (210 * resources.displayMetrics.density).toInt())
    }

    private fun stroke(width: Float = 3f, color: Int = ink) {
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = width * resources.displayMetrics.density / 2f
        p.strokeCap = Paint.Cap.ROUND; p.color = color
    }

    private fun text(c: Canvas, t: String, x: Float, y: Float, size: Float = 12f) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = ink
        p.textSize = size * resources.displayMetrics.scaledDensity
        c.drawText(t, x, y, p)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Color.parseColor("#F3EBDD"))
        stroke()
        when (type) {
            "garis" -> {
                for (i in 0..4) c.drawLine(w * 0.05f, h * (0.15f + i * 0.17f), w * 0.33f, h * (0.15f + i * 0.17f), p)
                val path = Path()
                path.moveTo(w * 0.40f, h * 0.55f)
                path.cubicTo(w * 0.44f, h * 0.05f, w * 0.48f, h * 0.95f, w * 0.52f, h * 0.55f)
                path.cubicTo(w * 0.55f, h * 0.2f, w * 0.58f, h * 0.9f, w * 0.60f, h * 0.5f)
                c.drawPath(path, p)
                for (i in 0..10) c.drawLine(w * 0.68f + i * w * 0.025f, h * 0.10f, w * 0.68f + i * w * 0.025f - w * 0.06f, h * 0.45f, p)
                for (i in 0..10) c.drawLine(w * 0.68f + i * w * 0.025f - w * 0.06f, h * 0.55f, w * 0.68f + i * w * 0.025f, h * 0.90f, p)
                for (i in 0..10) c.drawLine(w * 0.68f + i * w * 0.025f, h * 0.55f, w * 0.68f + i * w * 0.025f - w * 0.06f, h * 0.90f, p)
                text(c, "lurus", w * 0.05f, h * 0.97f); text(c, "lengkung", w * 0.38f, h * 0.97f); text(c, "arsiran", w * 0.70f, h * 0.97f)
            }
            "bentuk" -> {
                c.drawCircle(w * 0.2f, h * 0.48f, h * 0.30f, p)
                c.drawRect(w * 0.42f, h * 0.18f, w * 0.42f + h * 0.6f, h * 0.78f, p)
                val t = Path()
                t.moveTo(w * 0.86f, h * 0.18f); t.lineTo(w * 0.72f + 0.0f, h * 0.78f); t.lineTo(w * 0.98f, h * 0.78f); t.close()
                c.drawPath(t, p)
                text(c, "lingkaran", w * 0.10f, h * 0.95f); text(c, "kotak", w * 0.50f, h * 0.95f); text(c, "segitiga", w * 0.76f, h * 0.95f)
            }
            "3d" -> {
                val cx = w * 0.17f; val cy = h * 0.46f; val r = h * 0.28f
                p.style = Paint.Style.FILL
                p.shader = RadialGradient(cx - r * 0.35f, cy - r * 0.35f, r * 1.5f,
                    intArrayOf(Color.WHITE, Color.parseColor("#B8B0A4"), Color.parseColor("#3A332D")),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, r, p)
                stroke(); c.drawCircle(cx, cy, r, p)
                val s = h * 0.40f; val x0 = w * 0.38f; val y0 = h * 0.30f; val o = s * 0.35f
                c.drawRect(x0, y0, x0 + s, y0 + s, p)
                c.drawRect(x0 + o, y0 - o, x0 + s + o, y0 + s - o, p)
                c.drawLine(x0, y0, x0 + o, y0 - o, p); c.drawLine(x0 + s, y0, x0 + s + o, y0 - o, p)
                c.drawLine(x0 + s, y0 + s, x0 + s + o, y0 + s - o, p)
                val ox = w * 0.80f; val rx = w * 0.10f; val ry = h * 0.07f
                c.drawOval(RectF(ox - rx, h * 0.18f - ry, ox + rx, h * 0.18f + ry), p)
                c.drawArc(RectF(ox - rx, h * 0.72f - ry, ox + rx, h * 0.72f + ry), 0f, 180f, false, p)
                c.drawLine(ox - rx, h * 0.18f, ox - rx, h * 0.72f, p); c.drawLine(ox + rx, h * 0.18f, ox + rx, h * 0.72f, p)
                text(c, "bola", w * 0.12f, h * 0.95f); text(c, "kubus", w * 0.46f, h * 0.95f); text(c, "silinder", w * 0.74f, h * 0.95f)
            }
            "proporsi" -> {
                val cx = w * 0.28f; val cy = h * 0.5f; val rx = h * 0.26f; val ry = h * 0.40f
                c.drawOval(RectF(cx - rx, cy - ry, cx + rx, cy + ry), p)
                stroke(2f, Color.parseColor("#C0392B"))
                c.drawLine(cx, cy - ry, cx, cy + ry, p)
                c.drawLine(cx - rx, cy, cx + rx, cy, p)
                c.drawLine(cx - rx * 0.6f, cy + ry * 0.45f, cx + rx * 0.6f, cy + ry * 0.45f, p)
                text(c, "garis mata (tengah)", cx + rx * 1.1f, cy - 4f, 11f)
                text(c, "dasar hidung", cx + rx * 1.1f, cy + ry * 0.45f - 4f, 11f)
                stroke()
                val ew = w * 0.085f; val x0 = w * 0.60f; val y0 = h * 0.30f
                for (i in 0 until 5) c.drawOval(RectF(x0 + i * ew * 1.0f, y0, x0 + i * ew + ew * 0.9f, y0 + ew * 0.45f), p)
                text(c, "lebar wajah ~ 5 mata", x0 - w * 0.02f, y0 + ew * 1.4f, 11f)
            }
            "gelap" -> {
                val n = 7; val bw = w * 0.84f / n; val x0 = w * 0.08f
                p.style = Paint.Style.FILL
                for (i in 0 until n) {
                    val v = (245 - i * 38).coerceAtLeast(10)
                    p.color = Color.rgb(v, v, v)
                    c.drawRect(x0 + i * bw, h * 0.25f, x0 + (i + 1) * bw, h * 0.62f, p)
                    text(c, "" + (i + 1), x0 + i * bw + bw * 0.4f, h * 0.78f)
                }
                stroke(); c.drawRect(x0, h * 0.25f, x0 + bw * n, h * 0.62f, p)
                text(c, "terang", x0, h * 0.15f); text(c, "gelap", x0 + bw * n - w * 0.1f, h * 0.15f)
                text(c, "highlight   midtone   bayangan inti", x0, h * 0.95f, 11f)
            }
            "alat" -> {
                val names = listOf("2H", "H", "HB", "2B", "4B", "6B")
                val bw = w * 0.84f / names.size; val x0 = w * 0.08f
                p.style = Paint.Style.FILL
                for (i in names.indices) {
                    val v = (225 - i * 38).coerceAtLeast(20)
                    p.color = Color.rgb(v, v, v)
                    c.drawRect(x0 + i * bw + 4f, h * 0.2f, x0 + (i + 1) * bw - 4f, h * 0.6f, p)
                    text(c, names[i], x0 + i * bw + bw * 0.3f, h * 0.78f, 14f)
                }
                text(c, "keras / terang", x0, h * 0.13f, 11f); text(c, "lunak / gelap", x0 + bw * 4f, h * 0.13f, 11f)
            }
        }
    }
}

// Grafik radar untuk membandingkan gaya (5 sumbu, skala 0-5).
class RadarView(ctx: Context) : View(ctx) {
    var a = FloatArray(5)
    var b = FloatArray(5)
    private val labels = listOf("Garis tepi", "Penyederhanaan", "Bayangan", "Warna", "Detail")
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w)
        setMeasuredDimension(s, s)
    }

    private fun pt(i: Int, v: Float, cx: Float, cy: Float, r: Float): PointF {
        val ang = Math.toRadians(-90.0 + i * 72.0)
        return PointF(cx + (r * v / 5f * Math.cos(ang)).toFloat(), cy + (r * v / 5f * Math.sin(ang)).toFloat())
    }

    private fun poly(c: Canvas, vals: FloatArray, color: Int, cx: Float, cy: Float, r: Float) {
        val path = Path()
        for (i in 0 until 5) {
            val q = pt(i, vals[i], cx, cy, r)
            if (i == 0) path.moveTo(q.x, q.y) else path.lineTo(q.x, q.y)
        }
        path.close()
        p.style = Paint.Style.FILL; p.color = Color.argb(70, Color.red(color), Color.green(color), Color.blue(color))
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = color
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = width * 0.30f
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.parseColor("#4A423A")
        for (lv in 1..5) {
            val path = Path()
            for (i in 0 until 5) {
                val q = pt(i, lv.toFloat(), cx, cy, r)
                if (i == 0) path.moveTo(q.x, q.y) else path.lineTo(q.x, q.y)
            }
            path.close()
            c.drawPath(path, p)
        }
        for (i in 0 until 5) { val q = pt(i, 5f, cx, cy, r); c.drawLine(cx, cy, q.x, q.y, p) }
        poly(c, a, Color.parseColor("#E8A33D"), cx, cy, r)
        poly(c, b, Color.parseColor("#5AA9E6"), cx, cy, r)
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#D8D0C4")
        p.textSize = 13f * resources.displayMetrics.scaledDensity; p.textAlign = Paint.Align.CENTER
        for (i in 0 until 5) { val q = pt(i, 6.3f, cx, cy, r); c.drawText(labels[i], q.x, q.y, p) }
    }
}

// Studio referensi: abu-abu, 3/5 tone, cermin, dan grid di atas foto.
class StudioView(ctx: Context) : View(ctx) {
    var src: Bitmap? = null
    var shown: Bitmap? = null
    var mode = 0
    var mirror = false
    var grid = 0
    private val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dark = Paint().apply { color = Color.argb(160, 0, 0, 0); strokeWidth = 5f }
    private val light = Paint().apply { color = Color.argb(230, 255, 255, 255); strokeWidth = 2f }

    fun setImage(b: Bitmap) { src = b; rebuild() }

    fun rebuild() {
        val s = src
        if (s == null) { invalidate(); return }
        shown = when (mode) { 1 -> tone(s, 0); 2 -> tone(s, 3); 3 -> tone(s, 5); else -> s }
        invalidate()
    }

    private fun tone(s: Bitmap, levels: Int): Bitmap {
        val w = s.width; val h = s.height
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val col = px[i]
            var g = (0.299f * Color.red(col) + 0.587f * Color.green(col) + 0.114f * Color.blue(col)).toInt()
            if (levels > 1) {
                val step = 255f / (levels - 1)
                g = (Math.round(g / 255f * (levels - 1)) * step).toInt()
            }
            px[i] = Color.rgb(g, g, g)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w)
        setMeasuredDimension(s, (s * 1.15f).toInt())
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#0B0908"))
        val b = shown
        if (b == null) {
            p.color = Color.parseColor("#A89F94"); p.textAlign = Paint.Align.CENTER
            p.textSize = 14f * resources.displayMetrics.scaledDensity
            c.drawText("Pilih foto referensi dulu", width / 2f, height / 2f, p)
            return
        }
        val k = minOf(width / b.width.toFloat(), height / b.height.toFloat())
        val dw = b.width * k; val dh = b.height * k
        val l = (width - dw) / 2f; val t = (height - dh) / 2f
        c.save()
        if (mirror) c.scale(-1f, 1f, width / 2f, height / 2f)
        c.drawBitmap(b, null, RectF(l, t, l + dw, t + dh), p)
        if (grid > 0) {
            for (i in 1 until grid) {
                val x = l + dw * i / grid; val y = t + dh * i / grid
                c.drawLine(x, t, x, t + dh, dark); c.drawLine(l, y, l + dw, y, dark)
                c.drawLine(x, t, x, t + dh, light); c.drawLine(l, y, l + dw, y, light)
            }
        }
        c.restore()
    }
}
