package com.example.kamusgambar

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Vibrator
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.parseColor("#14110F")
    private val cardColor = Color.parseColor("#201B18")
    private val accent = Color.parseColor("#E8A33D")
    private val muted = Color.parseColor("#A89F94")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
    private val TABS = listOf("Belajar", "Kamus", "Gaya", "Alat", "Progres")

    private lateinit var prefs: SharedPreferences
    private lateinit var content: FrameLayout
    private lateinit var tabBar: LinearLayout
    private var tab = 0
    private var inDetail = false
    private var timer: CountDownTimer? = null
    private var studio: StudioView? = null

    // ---------- pembantu tampilan ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun label(t: String, size: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setLineSpacing(0f, 1.15f)
        }

    private fun cardOf(vararg views: View): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(cardColor, 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        views.forEachIndexed { i, v ->
            c.addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { if (i > 0) topMargin = dp(8) })
        }
        return c
    }

    private fun button(t: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(if (primary) Color.BLACK else Color.WHITE)
        background = box(if (primary) accent else Color.parseColor("#2E2824"), 12)
        setOnClickListener { onClick() }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEachIndexed { i, v ->
            addView(v, LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i > 0) leftMargin = dp(8) })
        }
    }

    private fun page(vararg views: View): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(20))
        }
        views.forEach { col.addView(it, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }) }
        return ScrollView(this).apply { setBackgroundColor(bg); addView(col) }
    }

    private fun spinner(items: List<String>, sel: Int, onSel: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    // ---------- navigasi ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("gambar", MODE_PRIVATE)
        window.statusBarColor = bg
        window.navigationBarColor = cardColor
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(cardColor) }
        TABS.forEachIndexed { i, t ->
            tabBar.addView(TextView(this).apply {
                text = t; gravity = Gravity.CENTER; textSize = 13f
                setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { showTab(i) }
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(tabBar, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        showTab(0)
    }

    private fun stopTimer() {
        timer?.cancel()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun showTab(i: Int) {
        stopTimer()
        tab = i
        inDetail = false
        studio = null
        for (k in 0 until tabBar.childCount) {
            (tabBar.getChildAt(k) as TextView).apply {
                setTextColor(if (k == i) accent else muted)
                setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL)
            }
        }
        val v = when (i) { 0 -> lessonList(); 1 -> glossary(); 2 -> styleScreen(); 3 -> toolsScreen(); else -> progressScreen() }
        content.removeAllViews()
        content.addView(v)
    }

    private fun openDetail(v: View) {
        inDetail = true
        content.removeAllViews()
        content.addView(v)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (inDetail) showTab(tab) else super.onBackPressed()
    }

    // ---------- Belajar ----------
    private fun lessonList(): View {
        val v = ArrayList<View>()
        v.add(label("Kamus Gambar", 26f, Color.WHITE, true))
        v.add(label("Pedoman dasar menggambar tradisional", 14f, muted))
        LESSONS.forEach { l ->
            val done = prefs.getBoolean("done_" + l.id, false)
            val c = cardOf(
                label(l.title, 17f, Color.WHITE, true),
                label(l.level + (if (done) "  •  selesai" else ""), 13f, if (done) accent else muted)
            )
            c.setOnClickListener { openDetail(lessonDetail(l)) }
            v.add(c)
        }
        return page(*v.toTypedArray())
    }

    private fun lessonDetail(l: Lesson): View {
        val v = ArrayList<View>()
        v.add(button("← Kembali", false) { showTab(tab) })
        v.add(label(l.title, 24f, Color.WHITE, true))
        v.add(DiagramView(this, l.diagram))
        v.add(cardOf(label("PENJELASAN", 12f, accent, true), label(l.body, 15f)))
        v.add(cardOf(label("LATIHAN", 12f, accent, true),
            *l.steps.mapIndexed { i, s -> label("${i + 1}. $s", 15f) }.toTypedArray()))
        val chks = l.check.mapIndexed { i, s ->
            CheckBox(this).apply {
                text = s; setTextColor(Color.WHITE)
                isChecked = prefs.getBoolean("chk_${l.id}_$i", false)
                setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("chk_${l.id}_$i", c).apply() }
            }
        }
        v.add(cardOf(label("CEK MANDIRI", 12f, accent, true), *chks.toTypedArray()))
        v.add(Switch(this).apply {
            text = "Pelajaran selesai"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("done_" + l.id, false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("done_" + l.id, c).apply() }
        })
        return page(*v.toTypedArray())
    }

    // ---------- Kamus ----------
    private fun glossary(): View {
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val search = EditText(this).apply {
            hint = "Cari istilah..."; setHintTextColor(muted); setTextColor(Color.WHITE); setSingleLine()
        }
        fun fill(q: String) {
            list.removeAllViews()
            TERMS.filter { q.isBlank() || it.term.contains(q, true) || it.def.contains(q, true) }.forEach { t ->
                list.addView(cardOf(label(t.term, 16f, accent, true), label(t.def, 14f)),
                    LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
            }
            if (list.childCount == 0) list.addView(label("Tidak ada istilah yang cocok.", 14f, muted))
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { fill(s.toString()) }
        })
        fill("")
        return page(label("Kamus Istilah", 24f, Color.WHITE, true),
            label("${TERMS.size} istilah, bisa dicari tanpa internet", 13f, muted), search, list)
    }

    // ---------- Gaya ----------
    private fun styleScreen(): View {
        val radar = RadarView(this)
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var ia = 0
        var ib = 2
        val blue = Color.parseColor("#5AA9E6")
        fun refresh() {
            radar.a = STYLES[ia].axes; radar.b = STYLES[ib].axes; radar.invalidate()
            info.removeAllViews()
            listOf(Pair(ia, accent), Pair(ib, blue)).forEach { pr ->
                val s = STYLES[pr.first]
                info.addView(
                    cardOf(label(s.name, 17f, pr.second, true), label(s.ciri, 14f),
                        label("Resep: menggambar mata", 12f, muted, true),
                        *s.resep.mapIndexed { k, r -> label("${k + 1}. $r", 14f) }.toTypedArray()),
                    LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
            }
        }
        val names = STYLES.map { it.name }
        val sa = spinner(names, 0) { ia = it; refresh() }
        val sb = spinner(names, 2) { ib = it; refresh() }
        refresh()
        return page(label("Peta Gaya", 24f, Color.WHITE, true),
            label("Bandingkan dua gaya di lima sumbu (0 sampai 5). Oranye = gaya pertama, biru = gaya kedua.", 13f, muted),
            label("Gaya pertama", 12f, accent, true), sa,
            label("Gaya kedua", 12f, blue, true), sb,
            radar, info,
            label("Nilai di peta adalah penyederhanaan untuk belajar, bukan aturan baku.", 12f, muted))
    }

    // ---------- Alat ----------
    private fun toolsScreen(): View {
        val t1 = cardOf(label("Timer Gesture", 17f, Color.WHITE, true),
            label("Sketsa cepat 30 detik sampai 5 menit dengan objek acak.", 13f, muted))
        t1.setOnClickListener { openDetail(timerScreen()) }
        val t2 = cardOf(label("Studio Referensi", 17f, Color.WHITE, true),
            label("Abu-abu, 3 dan 5 tone, mode cermin, dan grid di atas foto.", 13f, muted))
        t2.setOnClickListener { openDetail(studioScreen()) }
        return page(label("Alat Latihan", 24f, Color.WHITE, true), t1, t2)
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        try { (getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(500) } catch (_: Throwable) {}
    }

    private fun timerScreen(): View {
        val prompt = label("Pilih durasi untuk mulai", 18f, accent, true)
        val clock = label("00:00", 56f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        fun start(sec: Int) {
            stopTimer()
            prompt.text = "Gambar: " + PROMPTS.random()
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            timer = object : CountDownTimer(sec * 1000L, 250) {
                override fun onTick(ms: Long) {
                    val s = (ms + 999) / 1000
                    clock.text = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
                }
                override fun onFinish() {
                    clock.text = "Selesai!"
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    buzz()
                }
            }.start()
        }
        return page(button("← Kembali", false) { showTab(tab) },
            label("Timer Gesture", 24f, Color.WHITE, true),
            cardOf(prompt, clock),
            row(button("30 dtk", true) { start(30) }, button("1 mnt", true) { start(60) }),
            row(button("2 mnt", true) { start(120) }, button("5 mnt", true) { start(300) }),
            button("Berhenti", false) { stopTimer(); clock.text = "00:00" },
            label("Gesture menangkap gerak dan arah utama, bukan detail. Jangan angkat pensil terlalu sering.", 13f, muted))
    }

    private fun studioScreen(): View {
        val sv = StudioView(this)
        studio = sv
        val gridNames = listOf(0, 3, 4, 6)
        val gridBtn = button("Grid: mati", false) {}
        gridBtn.setOnClickListener {
            val nxt = gridNames[(gridNames.indexOf(sv.grid) + 1) % gridNames.size]
            sv.grid = nxt
            gridBtn.text = if (nxt == 0) "Grid: mati" else "Grid: ${nxt}x$nxt"
            sv.invalidate()
        }
        val mirBtn = button("Cermin: mati", false) {}
        mirBtn.setOnClickListener {
            sv.mirror = !sv.mirror
            mirBtn.text = if (sv.mirror) "Cermin: nyala" else "Cermin: mati"
            sv.invalidate()
        }
        fun mode(t: String, m: Int) = button(t, false) { sv.mode = m; sv.rebuild() }
        return page(button("← Kembali", false) { showTab(tab) },
            label("Studio Referensi", 24f, Color.WHITE, true),
            button("Pilih foto referensi", true) { pickImage(11) },
            sv,
            row(mode("Asli", 0), mode("Abu-abu", 1)),
            row(mode("3 tone", 2), mode("5 tone", 3)),
            row(mirBtn, gridBtn),
            label("3 dan 5 tone menyederhanakan foto jadi kelompok gelap-terang. Cermin membantu melihat kesalahan proporsi pada gambarmu. Grid membantu menyalin proporsi kotak demi kotak.", 13f, muted))
    }

    // ---------- Progres ----------
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun doneSet(): MutableSet<String> =
        (prefs.getString("done", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableSet()

    private fun streak(): Int {
        val days = doneSet()
        val cal = Calendar.getInstance()
        if (!days.contains(dayFmt.format(cal.time))) cal.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while (days.contains(dayFmt.format(cal.time))) { n++; cal.add(Calendar.DAY_OF_YEAR, -1) }
        return n
    }

    private fun progressDir() = File(filesDir, "prog").apply { mkdirs() }

    private fun thumb(f: File, sample: Int): Bitmap? =
        try { BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample }) } catch (_: Throwable) { null }

    private fun progressScreen(): View {
        val today = dayFmt.format(Date())
        val idx = (Calendar.getInstance().get(Calendar.DAY_OF_YEAR) + prefs.getInt("shuffle", 0)) % PRACTICE.size
        val parts = PRACTICE[idx].split(" | ")
        val streakTxt = label("Hari beruntun: ${streak()}", 15f, accent, true)
        val taskCard = cardOf(label("LATIHAN HARI INI", 12f, accent, true),
            label(parts[2], 16f, Color.WHITE, true),
            label(parts[0] + "  •  " + parts[1], 13f, muted),
            Switch(this).apply {
                text = "Sudah kulakukan hari ini"; setTextColor(Color.WHITE)
                isChecked = doneSet().contains(today)
                setOnCheckedChangeListener { _, c ->
                    val s = doneSet()
                    if (c) s.add(today) else s.remove(today)
                    prefs.edit().putString("done", s.joinToString(",")).apply()
                    streakTxt.text = "Hari beruntun: ${streak()}"
                }
            },
            streakTxt,
            button("Acak latihan lain", false) {
                prefs.edit().putInt("shuffle", prefs.getInt("shuffle", 0) + 1).apply(); showTab(4)
            })
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val files = progressDir().listFiles()?.filter { it.name.endsWith(".jpg") }?.sortedByDescending { it.name } ?: emptyList()
        val size = (resources.displayMetrics.widthPixels - dp(32) - dp(24)) / 3
        files.chunked(3).forEach { chunk ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { f ->
                val d = f.name
                val dateTxt = d.substring(6, 8) + "/" + d.substring(4, 6) + "/" + d.substring(0, 4)
                val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                cell.addView(ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageBitmap(thumb(f, 4))
                    setOnClickListener { showPhoto(f, dateTxt) }
                }, LinearLayout.LayoutParams(size, size))
                cell.addView(label(dateTxt, 11f, muted))
                r.addView(cell, LinearLayout.LayoutParams(size, WRAP).apply { rightMargin = dp(8); bottomMargin = dp(8) })
            }
            grid.addView(r)
        }
        if (files.isEmpty()) grid.addView(label("Belum ada foto. Foto gambar yang sama dari minggu ke minggu untuk melihat kemajuanmu.", 13f, muted))
        return page(label("Progres", 24f, Color.WHITE, true), taskCard,
            cardOf(label("LINIMASA GAMBAR", 12f, accent, true),
                button("Tambah foto gambarku", true) { pickImage(12) }, grid))
    }

    private fun showPhoto(f: File, dateTxt: String) {
        val bmp = BitmapFactory.decodeFile(f.path)
        val iv = ImageView(this).apply { setImageBitmap(bmp); adjustViewBounds = true }
        AlertDialog.Builder(this).setTitle(dateTxt).setView(iv)
            .setPositiveButton("Tutup", null)
            .setNegativeButton("Hapus") { _, _ -> f.delete(); showTab(4) }.show()
    }

    // ---------- gambar dari galeri ----------
    private fun pickImage(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
        }
        startActivityForResult(i, code)
    }

    private fun loadBitmap(uri: Uri, max: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            val raw = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val rot = contentResolver.openInputStream(uri)?.use {
                try {
                    when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                        6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                    }
                } catch (_: Throwable) { 0f }
            } ?: 0f
            val k = minOf(1f, max.toFloat() / maxOf(raw.width, raw.height))
            val m = Matrix().apply { postScale(k, k); if (rot != 0f) postRotate(rot) }
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        } catch (_: Throwable) { null }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            11 -> {
                val b = loadBitmap(uri, 1000)
                if (b != null) studio?.setImage(b) else toast("Gagal membuka foto")
            }
            12 -> {
                val b = loadBitmap(uri, 1280)
                if (b == null) { toast("Gagal membuka foto"); return }
                val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
                File(progressDir(), name).outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                showTab(4)
            }
        }
    }

    override fun onDestroy() {
        stopTimer()
        super.onDestroy()
    }
}
